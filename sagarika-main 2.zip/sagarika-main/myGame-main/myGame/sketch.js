
var gameState=0
function preload(){
girlAn=loadAnimation("assets/girl/g1.png","assets/girl/g2.png","assets/girl/g3.png","assets/girl/g4.png",
"assets/girl/g5.png","assets/girl/g6.png","assets/girl/g7.png","assets/girl/g8.png","assets/girl/g9.png","assets/girl/g10.png");
bg1=loadImage("assets/background1.jpg")

sound1=loadSound("assets/scary_bells.mp3")
sound2=loadSound("assets/bonus_room_blitz.mp3")
sound3=loadSound("assets/knight.mp3")
coins=loadSound("assets/mario_coin_tone.mp3")


pumkinImg=loadAnimation("assets/pumkin/po.png","assets/pumkin/po2.png")
w1=loadAnimation("assets/witch1/w1.png","assets/witch1/w2.png","assets/witch1/w3.png","assets/witch1/w4.png","assets/witch1/w5.png","assets/witch1/w6.png")
w2=loadAnimation("assets/witch2/w1.png","assets/witch2/w2.png","assets/witch2/w3.png","assets/witch2/w4.png")

d=loadAnimation("assets/dragon/g1.png","assets/dragon/g2.png","assets/dragon/g3.png","assets/dragon/g4.png","assets/dragon/g5.png","assets/dragon/g6.png","assets/dragon/g7.png","assets/dragon/g8.png","assets/dragon/g9.png","assets/dragon/g10.png","assets/dragon/g11.png","assets/dragon/g12.png","assets/dragon/g13.png","assets/dragon/g14.png")
c=loadAnimation("assets/cactus/c1.png","assets/cactus/c2.png","assets/cactus/c3.png","assets/cactus/c4.png","assets/cactus/c5.png")
metal=loadAnimation("assets/metal/m1.png","assets/metal/m2.png","assets/metal/m3.png","assets/metal/m4.png")
monster=loadAnimation("assets/mummy/m1.png","assets/mummy/m2.png","assets/mummy/m3.png","assets/mummy/m4.png","assets/mummy/m5.png")
saw=loadImage("saw.png")
}


function setup(){
    createCanvas(displayWidth,displayHeight);
    girl = createSprite(350,displayHeight-170,40,100);
    girl.addAnimation("run",girlAn)
    girl.scale=0.3;
   
    ground= createSprite(0,500,displayWidth,displayHeight);
    ground.addImage("bg",bg1)
    


halloObsGroup=new Group()

}

function draw(){
    background(0);
    ground.velocityX=-3
   if(gameState===0){
    sound1.play()
    halloweenObs()
   }
else if(gameState===1)
{
        jungleObs()  

}
    
    if(ground.x<displayWidth){
        ground.x=ground.width/2;
    }
    
    drawSprites();
     gates()
      

}


function halloweenObs(){
    if(frameCount % 260 === 0) {
        var obstacle = createSprite(displayWidth,displayHeight-140,10,40);
        //obstacle.debug = true;
        obstacle.velocityX = -6;
        
        //generate random obstacles
        var rand = Math.round(random(1,3));
        switch(rand) {
          case 1: obstacle.addAnimation("obstacle1",w1);
                  break;
          case 2: obstacle.addAnimation("obstacle2",w2);
                  break;
          case 3: obstacle.addAnimation("obstacle3",pumkinImg);
                  break;
          default: break;
        }
        
        //assign scale and lifetime to the obstacle           
        obstacle.scale = 1.1;
        obstacle.lifetime = 900;
        //add each obstacle to the group
        halloObsGroup.add(obstacle);
      }

}

function jungleObs(){
    if(frameCount % 260 === 0) {
        var obstacle = createSprite(displayWidth,displayHeight-140,10,40);
        //obstacle.debug = true;
        obstacle.velocityX = -6;
        
        //generate random obstacles
        var rand = Math.round(random(1,3));
        switch(rand) {
          case 1: obstacle.addAnimation("obstacle1",c);
                  break;
          case 2: obstacle.addAnimation("obstacle2",metal);
                  break;
          case 3: obstacle.addImage("obstacle3",saw);
                  break;
          default: break;
        }
        
        //assign scale and lifetime to the obstacle           
        obstacle.scale = 1.1;
        obstacle.lifetime = 900;
        //add each obstacle to the group
        halloObsGroup.add(obstacle);
      }

    
}

function dungeonObs(){
if(frameCount % 260 === 0) {
        var obstacle = createSprite(displayWidth,displayHeight-140,10,40);
        //obstacle.debug = true;
        obstacle.velocityX = -6;
        
        //generate random obstacles
        var rand = Math.round(random(1,3));
        switch(rand) {
          case 1: obstacle.addAnimation("obstacle1",mummy);
                  break;
          case 2: obstacle.addAnimation("obstacle2",monster);
                  break;
          default: break;
        }
        
        //assign scale and lifetime to the obstacle           
        obstacle.scale = 1.1;
        obstacle.lifetime = 900;
        //add each obstacle to the group
        halloObsGroup.add(obstacle);
      }
}   
function gates(){
    if(frameCount % 600 === 0) {
        var obstacle = createSprite(displayWidth,displayHeight-140,10,40);
        //obstacle.debug = true;
        obstacle.velocityX = -6;
        
        //assign scale and lifetime to the obstacle           
        obstacle.scale = 1.1;
        obstacle.lifetime = 900;
      }
}